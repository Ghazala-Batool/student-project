<?php
// SIMPLE VERSION - No config file needed

// Connect to database
$conn = mysqli_connect("localhost", "root", "", "roasted_bean_db");

// If database doesn't exist, create it
if (!$conn) {
    $conn = mysqli_connect("localhost", "root", "");
    if ($conn) {
        mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS roasted_bean_db");
        mysqli_select_db($conn, "roasted_bean_db");
        
        // Create contacts table
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS contacts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            message TEXT NOT NULL,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
    }
}

// Check connection
if (!$conn) {
    die("Database connection failed. Please check if XAMPP is running.");
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Basic validation
if (empty($name) || empty($email) || empty($message)) {
    header("Location: contact.php?error=All fields are required");
    exit();
}

// Insert into database
$sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";

if (mysqli_query($conn, $sql)) {
    header("Location: contact.php?success=1");
} else {
    header("Location: contact.php?error=" . urlencode(mysqli_error($conn)));
}

mysqli_close($conn);
?>